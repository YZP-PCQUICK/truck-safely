from machine import Pin
from machine import Pin, PWM, SPI, I2C
import st7789_itprojects
import time
import math
import machine

a = Pin(15, Pin.OUT)
b = Pin(2, Pin.OUT)
c = Pin(4, Pin.OUT)
d = Pin(16, Pin.OUT)
i2c= I2C(scl = Pin(22),sda = Pin(21),freq = 100000)
tft = st7789_itprojects.ST7889_Image(SPI(2, 60000000), dc=Pin(14), cs=Pin(27), rst=Pin(12))
tft.fill(st7789_itprojects.color565(0, 0, 0))
a.value(0)
b.value(0)
c.value(0)
d.value(0)
delay_time_ms =5

def vl53l0x_start():
    i2c.writeto_mem(0x29,0x00,chr(1))
    time.sleep_us(1)
    data_i2c = i2c.readfrom_mem(0x29,0x1e,2)
    data_i2c = data_i2c[0]<< 8 | data_i2c[1]
    if data_i2c != 20:
        return data_i2c

while True:
    tft.fill(st7789_itprojects.color565(0, 0, 0))
    for i in range(263):
        a.value(1)
        b.value(0)
        c.value(0)
        d.value(0)
        time.sleep_ms(delay_time_ms)
        
        a.value(0)
        b.value(1)
        c.value(0)
        d.value(0)
        time.sleep_ms(delay_time_ms)
        
        a.value(0)
        b.value(0)
        c.value(1)
        d.value(0)
        time.sleep_ms(delay_time_ms)
        
        a.value(0)
        b.value(0)
        c.value(0)
        d.value(1)
        time.sleep_ms(delay_time_ms)
        
        m=i/263*math.pi
        n=vl53l0x_start()
        if n != None:
            x=int(n*math.cos(m)+120)
            y=int(n*math.sin(m))
            tft.pixel(x,y, st7789_itprojects.color565(240, 0, 0))

    tft.fill(st7789_itprojects.color565(0, 0, 0))
    for i in range(263):
        a.value(0)
        b.value(0)
        c.value(0)
        d.value(1)
        time.sleep_ms(delay_time_ms)
        
        a.value(0)
        b.value(0)
        c.value(1)
        d.value(0)
        time.sleep_ms(delay_time_ms)
        
        a.value(0)
        b.value(1)
        c.value(0)
        d.value(0)
        time.sleep_ms(delay_time_ms)
        
        a.value(1)
        b.value(0)
        c.value(0)
        d.value(0)
        time.sleep_ms(delay_time_ms)
        
        m=i/263*math.pi
        n=vl53l0x_start()
        if n != None:
            x=int(n*math.cos(m)+120)
            y=int(n*math.sin(m))
            tft.pixel(x,y, st7789_itprojects.color565(240, 0, 0))