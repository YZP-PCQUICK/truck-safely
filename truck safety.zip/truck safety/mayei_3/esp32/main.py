from machine import Pin, PWM, SPI, I2C
import time
import st7789_itprojects
import math
import machine

i2c= I2C(scl = Pin(22),sda = Pin(21),freq = 100000)
i2c_1= I2C(scl = Pin(16),sda = Pin(17),freq = 100000)
buzzer = machine.Pin(13, machine.Pin.OUT)
tft = st7789_itprojects.ST7889_Image(SPI(2, 60000000), dc=Pin(14), cs=Pin(27), rst=Pin(12))
tft.fill(st7789_itprojects.color565(0, 0, 0))
tft.line(0,80,180,80, st7789_itprojects.color565(240, 0, 0))
tft.line(0,160,180,160, st7789_itprojects.color565(240, 0, 0))
tft.line(180,160,180,80, st7789_itprojects.color565(240, 0, 0))
p4 = PWM(Pin(4))
p4.freq(50)
p4.duty_u16(1638)
p15 = PWM(Pin(15))
p15.freq(50)
p15.duty_u16(1638)
num=1638
a=0
t=10
num_1=1638
a_1=0
t_1=10

def vl53l0x_start():
    i2c.writeto_mem(0x29,0x00,chr(1))
    time.sleep_us(1)
    data_i2c = i2c.readfrom_mem(0x29,0x1e,2)
    data_i2c = data_i2c[0]<< 8 | data_i2c[1]
    if data_i2c != 20:
        return data_i2c
    else :
        return None
    
def vl53l0x_start_1():
    i2c_1.writeto_mem(0x29,0x00,chr(1))
    time.sleep_us(1)
    data_i2c_1 = i2c_1.readfrom_mem(0x29,0x1e,2)
    data_i2c_1 = data_i2c_1[0]<< 8 | data_i2c_1[1]
    if data_i2c_1 != 20:
        return data_i2c_1
    else :
        return None

while True:
    buzzer.value(0)
    m=(num-1638)/6550*math.pi
    m_1=(num_1-1638)/6550*math.pi
    n=vl53l0x_start()
    n_1=vl53l0x_start_1()
    
    if n!=None:
        if n < 10:
            buzzer.value(1)
    else:
        n=0
    x=int((n*math.cos(m))/5+120)
    y=int((n*math.sin(m))/5+160)
    
    if n_1!=None:
        if n_1 < 10:
            buzzer.value(1)
    else:
        n_1=0
    x_1=int((n_1*math.cos(m_1))/5+120)
    y_1=int(-(n_1*math.sin(m_1))/5+80)

    if num < 8138 and a==0 and num_1 < 8138 and a_1==0:
        p4.duty_u16(num)
        num+=50
        tft.pixel(x,y, st7789_itprojects.color565(240, 0, 0))
        time.sleep_us(t)
        p15.duty_u16(num_1)
        num_1+=50
        tft.pixel(x_1,y_1, st7789_itprojects.color565(240, 0, 0))
        time.sleep_us(t_1)
        
    elif num == 8138 and a==0 and num_1 == 8138 and a_1==0:
        a=1
        tft.fill(st7789_itprojects.color565(0, 0, 0))
        tft.line(0,80,180,80, st7789_itprojects.color565(240, 0, 0))
        tft.line(0,160,180,160, st7789_itprojects.color565(240, 0, 0))
        tft.line(180,160,180,80, st7789_itprojects.color565(240, 0, 0))
        time.sleep_us(t)
        a_1=1
        time.sleep_us(t_1)
        
    elif num >1638 and a==1 and num_1 >1638 and a_1==1:
        p4.duty_u16(num)
        num-=50
        tft.pixel(x,y, st7789_itprojects.color565(240, 0, 0))
        time.sleep_us(t)
        p15.duty_u16(num_1)
        num_1-=50
        tft.pixel(x_1,y_1, st7789_itprojects.color565(240, 0, 0))
        time.sleep_us(t_1) 
        
    elif num == 1638 and a==1 and num_1 == 1638 and a_1==1:
        a=0
        tft.fill(st7789_itprojects.color565(0, 0, 0))
        tft.line(0,80,180,80, st7789_itprojects.color565(240, 0, 0))
        tft.line(0,160,180,160, st7789_itprojects.color565(240, 0, 0))
        tft.line(180,160,180,80, st7789_itprojects.color565(240, 0, 0))
        time.sleep_us(t)
        a_1=0
        time.sleep_us(t_1)


