import socket
import cv2
import numpy as np
import dlib
import time
from imutils import face_utils
from scipy.spatial import distance

# 初始化UDP套接字
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind(("0.0.0.0", 8888))

# 3D人脸模型参考点（基于68个特征点）
FACE_3D_MODEL = np.array([
    (0.0, 0.0, 0.0),             # 鼻尖（30号点）
    (0.0, -330.0, -65.0),        # 下巴（8号点）
    (-225.0, 170.0, -135.0),     # 左眼角（36号点）
    (225.0, 170.0, -135.0),      # 右眼角（45号点）
    (-150.0, -150.0, -125.0),    # 左嘴角（48号点）
    (150.0, -150.0, -125.0)      # 右嘴角（54号点）
], dtype=np.float64)

# 定义纵横比函数
def eye_aspect_ratio(eye):
    A = distance.euclidean(eye[1], eye[5])
    B = distance.euclidean(eye[2], eye[4])
    C = distance.euclidean(eye[0], eye[3])
    return (A + B) / (2.0 * C)

def mouth_aspect_ratio(mouth):
    A = distance.euclidean(mouth[3], mouth[9])  # 上下唇距离
    B = distance.euclidean(mouth[0], mouth[6])  # 嘴角宽度
    return A / B

# 加载模型
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor("F:\software\Application\shape_predictor_68_face_landmarks.dat\shape_predictor_68_face_landmarks.dat")

# 配置参数
EAR_THRESHOLD = 0.24
MAR_THRESHOLD = 0.5
HEAD_PITCH_THRESH = 15.0   # 点头角度阈值（度）
NOD_DURATION = 1.0         # 点头持续时间阈值（秒）
EYE_CONSEC_FRAMES = 5

# 状态变量
eye_counter = 0
mouth_open_start = None
nod_start_time = None
last_pitch = 0.0

def get_head_pose(shape, size):
    # 选择关键点索引（基于dlib 68点模型）
    landmarks = [30, 8, 36, 45, 48, 54]
    image_points = np.array([shape[i] for i in landmarks], dtype=np.float64)
    
    # 估算相机参数
    h, w = size
    focal_length = w * 1.0  # 使用宽度作为焦距估计
    camera_matrix = np.array([
        [focal_length, 0, w/2],
        [0, focal_length, h/2],
        [0, 0, 1]
    ], dtype=np.float64)
    
    # 计算旋转和平移向量
    _, rot_vec, trans_vec = cv2.solvePnP(
        FACE_3D_MODEL,
        image_points,
        camera_matrix,
        None,
        flags=cv2.SOLVEPNP_ITERATIVE
    )
    
    # 转换为欧拉角（pitch, yaw, roll）
    rmat, _ = cv2.Rodrigues(rot_vec)
    angles = cv2.RQDecomp3x3(rmat)[0]
    return angles  # 顺序为pitch, yaw, roll

while True:
    data, addr = s.recvfrom(65535)
    img_np = np.frombuffer(data, np.uint8)
    img = cv2.imdecode(img_np, cv2.IMREAD_COLOR)
    
    if img is None:
        continue
    
    # 初始化参数
    ear = mar = pitch = 0.0
    alert_text = ""
    h, w = img.shape[:2]
    
    # 图像预处理
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)
    gray = cv2.GaussianBlur(gray, (3,3), 0)
    
    # 人脸检测
    rects = detector(gray, 1)
    
    if len(rects) > 0:
        rect = max(rects, key=lambda r: r.width()*r.height())
        shape = predictor(gray, rect)
        shape = face_utils.shape_to_np(shape)
        
        # 头部姿态计算
        angles = get_head_pose(shape, (h, w))
        pitch, yaw, roll = angles
        
        # 特征检测
        left_eye = shape[42:48]
        right_eye = shape[36:42]
        ear = (eye_aspect_ratio(left_eye) + eye_aspect_ratio(right_eye)) / 2.0
        
        mouth = shape[48:68]
        mar = mouth_aspect_ratio(mouth)
        
        # 绘制特征点
        cv2.drawContours(img, [cv2.convexHull(left_eye)], -1, (0,255,0), 1)
        cv2.drawContours(img, [cv2.convexHull(right_eye)], -1, (0,255,0), 1)
        cv2.drawContours(img, [cv2.convexHull(mouth)], -1, (0,255,255), 1)
        
        # 头部姿态报警逻辑
        current_pitch = abs(pitch)
        if abs(current_pitch - last_pitch) > HEAD_PITCH_THRESH:
            if nod_start_time is None:
                nod_start_time = time.time()
            elif time.time() - nod_start_time >= NOD_DURATION:
                alert_text += "NOD ALERT! "
        else:
            nod_start_time = None
        
        last_pitch = current_pitch
        
        # 眼睛报警逻辑
        if ear < EAR_THRESHOLD:
            eye_counter += 1
            if eye_counter >= EYE_CONSEC_FRAMES:
                alert_text += "EYE ALERT! "
        else:
            eye_counter = 0
            
        # 嘴巴报警逻辑
        if mar > MAR_THRESHOLD:
            if mouth_open_start is None:
                mouth_open_start = time.time()
            elif time.time() - mouth_open_start >= NOD_DURATION:
                alert_text += "MOUTH ALERT! "
        else:
            mouth_open_start = None
    else:
        # 无人脸时重置状态
        eye_counter = 0
        mouth_open_start = None
        nod_start_time = None
        last_pitch = 0.0
    
    # 显示信息
    cv2.putText(img, alert_text, (10, 30), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,255), 2)
    cv2.putText(img, f"EAR: {ear:.2f}", (w-200,30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,0), 1)
    cv2.putText(img, f"MAR: {mar:.2f}", (w-200,60),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,0), 1)
    cv2.putText(img, f"Pitch: {pitch:.1f}deg", (w-200,90),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,0), 1)
    
    cv2.imshow("Driver Monitoring", img)
    if cv2.waitKey(1) == ord('q'):
        break

cv2.destroyAllWindows()
s.close()